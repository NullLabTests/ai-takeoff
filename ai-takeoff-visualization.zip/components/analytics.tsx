"use client"

import { useEffect } from "react"

export function Analytics() {
  useEffect(() => {
    // This is where you would add your analytics code
    // For example, Google Analytics or Plausible
    console.log("Analytics loaded")
  }, [])

  return null
}

